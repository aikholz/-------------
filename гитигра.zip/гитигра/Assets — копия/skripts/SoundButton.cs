using UnityEngine;

public class SoundButton : MonoBehaviour
{
    public void Toggle()
    {
        if (MusicManager.Instance != null)
        {
            MusicManager.Instance.ToggleSound();
        }
    }
}