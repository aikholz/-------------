using UnityEngine;
using System.Collections;

// Управляет движением персонажа, анимацией и звуком шагов
public class heroGo : MonoBehaviour
{
    // Скорость передвижения персонажа
    public float speed = 5f;

    [Header("Footsteps")]
    // Звук шагов
    [SerializeField] private AudioClip footstepSound;

    // Интервал между звуками шагов (в секундах)
    [SerializeField] private float footstepInterval = 0.4f;

    // Компонент физики для перемещения
    private Rigidbody2D rb;

    // Вектор направления движения (по X и Y)
    private Vector2 moveInput;

    // Компонент анимаций (Idle, Run)
    private Animator animator;

    // Источник звука для шагов
    private AudioSource audioSource;

    // Флаг: идёт ли персонаж сейчас
    private bool isWalking = false;

    // Таймер для воспроизведения шагов с интервалом
    private float footstepTimer;

    void Start()
    {
        // Получаем компоненты с объекта
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();

        // Если AudioSource отсутствует — добавляем его автоматически
        if (audioSource == null)
            audioSource = gameObject.AddComponent<AudioSource>();
    }

    void Update()
    {
        // Получаем ввод с клавиатуры (WASD или стрелки)
        float moveX = Input.GetAxisRaw("Horizontal");
        float moveY = Input.GetAxisRaw("Vertical");

        // Формируем вектор движения и нормализуем (чтобы по диагонали скорость не была выше)
        moveInput = new Vector2(moveX, moveY).normalized;

        // Поворот персонажа в сторону движения (отражение спрайта по X)
        if (moveX != 0)
        {
            transform.localScale = new Vector3(Mathf.Sign(moveX), 1, 1);
        }

        // Проверяем, движется ли персонаж (длина вектора > 0.1)
        isWalking = moveInput.magnitude > 0.1f;

        // Звук шагов с интервалом
        if (isWalking)
        {
            footstepTimer -= Time.deltaTime;    // Уменьшаем таймер
            if (footstepTimer <= 0f)            // Когда таймер истёк — проигрываем шаг
            {
                PlayFootstep();
                footstepTimer = footstepInterval;   // Сбрасываем таймер
            }
        }
        else
        {
            footstepTimer = 0f;     // Сбрасываем таймер, если стоим на месте
        }
    }

    // FixedUpdate вызывается с фиксированным интервалом (для физики)
    void FixedUpdate()
    {
        // Применяем скорость к Rigidbody2D
        rb.velocity = moveInput * speed;

        // Управление анимацией: если движемся — Run, иначе — Idle
        if (animator != null)
        {
            animator.SetBool("isRun", moveInput.magnitude > 0.1f);
        }
    }

    // Проигрывает звук шага с небольшим случайным изменением высоты тона
    // Это делает звук более естественным
    private void PlayFootstep()
    {
        if (footstepSound != null && audioSource != null)
        {
            // Случайное изменение pitch (0.9 — 1.1) для разнообразия звука
            audioSource.pitch = Random.Range(0.9f, 1.1f);

            // Проигрываем звук шага
            audioSource.PlayOneShot(footstepSound);
        }
    }
}