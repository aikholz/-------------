using UnityEngine;
using UnityEngine.EventSystems;

// Вешается на каждую кнопку. Меняет курсор при наведении.
// IPointerEnterHandler — когда курсор заходит на кнопку
// IPointerExitHandler — когда курсор уходит с кнопки
public class CursorButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    // Ссылка на CursorManager (находится автоматически)
    private CursorManager cursorManager;

    // Запоминаем исходный размер кнопки
    private Vector3 originalScale;

    // Коэффициент увеличения при наведении (по умолчанию 1.2 = 120%)
    [SerializeField] private float hoverScale = 1.2f;

    // Флаг для кнопки-шестерёнки — если включён, кнопка будет увеличиваться при наведении
    [SerializeField] private bool isSettingsButton = false;

    void Start()
    {
        // Находим CursorManager на сцене
        cursorManager = FindObjectOfType<CursorManager>();

        // Запоминаем исходный размер кнопки
        originalScale = transform.localScale;
    }

    // Курсор зашёл на кнопку — меняем спрайт курсора и увеличиваем (если шестерёнка)
    public void OnPointerEnter(PointerEventData eventData)
    {
        if (cursorManager != null)
            cursorManager.SetButtonCursor();  // Меняем курсор на "кнопочный"

        if (isSettingsButton)
            transform.localScale = originalScale * hoverScale;  // Увеличиваем кнопку
    }

    // Курсор ушёл с кнопки — возвращаем обычный курсор и исходный размер
    public void OnPointerExit(PointerEventData eventData)
    {
        if (cursorManager != null)
            cursorManager.SetDefaultCursor();  // Возвращаем обычный курсор

        if (isSettingsButton)
            transform.localScale = originalScale;  // Возвращаем исходный размер
    }
}