using UnityEngine;

// Управляет кнопкой-шестерёнкой и панелью паузы
// Вешается на кнопку Settings (шестерёнка в углу экрана)
public class SettingsButton : MonoBehaviour
{
    // Ссылка на панель паузы (всплывающее окно с кнопками Resume и Quit)
    [SerializeField] private GameObject pausePanel;

    void Start()
    {
        // При старте уровня панель паузы скрыта
        if (pausePanel != null)
            pausePanel.SetActive(false);
    }

    // Вызывается при нажатии на шестерёнку — открывает панель паузы
    public void OpenPauseMenu()
    {
        if (pausePanel != null)
        {
            pausePanel.SetActive(true);     // Показываем панель
            Time.timeScale = 0f;            // Останавливаем игру
        }
    }

    // Вызывается при нажатии кнопки Resume — продолжает игру
    public void ResumeGame()
    {
        if (pausePanel != null)
        {
            pausePanel.SetActive(false);    // Скрываем панель
            Time.timeScale = 1f;            // Восстанавливаем течение времени
        }
    }

    // Вызывается при нажатии кнопки Quit to Menu — выходит в главное меню
    public void QuitToMainMenu()
    {
        Time.timeScale = 1f;                // Сбрасываем паузу
        UnityEngine.SceneManagement.SceneManager.LoadScene("MainMenu");
    }
}