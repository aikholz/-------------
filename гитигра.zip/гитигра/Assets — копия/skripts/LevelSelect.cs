using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class LevelSelect : MonoBehaviour
{
    [Header("Coins Display Text")]
    [SerializeField] private TextMeshProUGUI coinsTextLev1;
    [SerializeField] private TextMeshProUGUI coinsTextLev2;
    [SerializeField] private TextMeshProUGUI coinsTextLev3;

    [Header("Time Display Text")]
    [SerializeField] private TextMeshProUGUI timeTextLev1;
    [SerializeField] private TextMeshProUGUI timeTextLev2;
    [SerializeField] private TextMeshProUGUI timeTextLev3;

    [Header("Total Coins Per Level")]
    [SerializeField] private int totalCoinsLev1 = 25;
    [SerializeField] private int totalCoinsLev2 = 30;
    [SerializeField] private int totalCoinsLev3 = 30;

    void Start()
    {
        UpdateDisplay();
    }

    private void UpdateDisplay()
    {
        // Lev1
        if (coinsTextLev1 != null)
        {
            int collected = PlayerPrefs.GetInt("Lev1_Coins", 0);
            coinsTextLev1.text = $"{collected}/{totalCoinsLev1}\nCoins";
        }
        if (timeTextLev1 != null)
        {
            float bestTime = PlayerPrefs.GetFloat("Lev1_BestTime", 0);
            timeTextLev1.text = bestTime > 0 ? FormatTime(bestTime) : "00:00";
        }

        // Lev2
        if (coinsTextLev2 != null)
        {
            int collected = PlayerPrefs.GetInt("Lev2_Coins", 0);
            coinsTextLev2.text = $"{collected}/{totalCoinsLev2}\nCoins";
        }
        if (timeTextLev2 != null)
        {
            float bestTime = PlayerPrefs.GetFloat("Lev2_BestTime", 0);
            timeTextLev2.text = bestTime > 0 ? FormatTime(bestTime) : "00:00";
        }

        // Lev3
        if (coinsTextLev3 != null)
        {
            int collected = PlayerPrefs.GetInt("Lev3_Coins", 0);
            coinsTextLev3.text = $"{collected}/{totalCoinsLev3}\nCoins";
        }
        if (timeTextLev3 != null)
        {
            float bestTime = PlayerPrefs.GetFloat("Lev3_BestTime", 0);
            timeTextLev3.text = bestTime > 0 ? FormatTime(bestTime) : "00:00";
        }
    }

    private string FormatTime(float seconds)
    {
        int min = Mathf.FloorToInt(seconds / 60);
        int sec = Mathf.FloorToInt(seconds % 60);
        return $"{min:00}:{sec:00}";
    }

    public void LoadLevel1() => SceneManager.LoadScene("Lev1");
    public void LoadLevel2() => SceneManager.LoadScene("Lev2");
    public void LoadLevel3() => SceneManager.LoadScene("Lev3");
    public void BackToMenu() => SceneManager.LoadScene("MainMenu");
}