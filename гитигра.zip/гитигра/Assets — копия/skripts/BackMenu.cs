using UnityEngine;
using UnityEngine.SceneManagement;

public class BackMenu : MonoBehaviour
{
    // Загружает сцену главного меню
    // Вызывается при нажатии кнопки "Back" в меню выбора уровней
    public void GoToMainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }
}