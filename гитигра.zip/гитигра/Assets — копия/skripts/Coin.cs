using UnityEngine;

public class Coin : MonoBehaviour
{
    // Номинал монеты (сколько очков даётся за сбор, по умолчанию 1)
    [SerializeField] private int coinValue = 1;

    // Звук, который проигрывается при сборе монеты
    [SerializeField] private AudioClip collectSound;

    // Срабатывает при касании коллайдера игрока 
    private void OnTriggerEnter2D(Collider2D other)
    {
        // Проверяем, что коснулся именно игрок (тег "Player")
        if (other.CompareTag("Player"))
        {
            // Увеличиваем счётчик монет через GameManager
            if (GameManager.Instance != null)
                GameManager.Instance.AddCoins(coinValue);

            // Проигрываем звук сбора монеты в точке её расположения
            // 3.0f — громкость звука (можно менять)
            if (collectSound != null)
                AudioSource.PlayClipAtPoint(collectSound, transform.position, 3.0f);

            // Уничтожаем объект монеты (она исчезает с уровня)
            Destroy(gameObject);
        }
    }
}