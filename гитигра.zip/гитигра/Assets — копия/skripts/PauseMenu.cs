using UnityEngine;
using UnityEngine.SceneManagement;

// Управляет меню паузы (открывается по клавише Escape)
public class PauseMenu : MonoBehaviour
{
    // Ссылка на панель паузы (всплывающее окно с кнопками Resume и Quit)
    [SerializeField] private GameObject pausePanel;

    // Флаг: стоит ли игра на паузе
    private bool isPaused = false;

    void Start()
    {
        // При старте уровня панель паузы скрыта
        if (pausePanel != null)
            pausePanel.SetActive(false);
    }

    void Update()
    {
        // При нажатии Escape переключаем паузу
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPaused)
                Resume();   // Если на паузе — продолжаем
            else
                Pause();    // Если играем — ставим на паузу
        }
    }

    // Продолжить игру: скрываем панель, восстанавливаем время
    public void Resume()
    {
        if (pausePanel != null)
            pausePanel.SetActive(false);

        Time.timeScale = 1f;    // Восстанавливаем течение времени
        isPaused = false;
    }

    // Поставить игру на паузу: показываем панель, останавливаем время
    public void Pause()
    {
        if (pausePanel != null)
            pausePanel.SetActive(true);

        Time.timeScale = 0f;    // Останавливаем время (все анимации и физика замирают)
        isPaused = true;
    }

    // Выйти в главное меню: сбрасываем паузу и загружаем MainMenu
    public void QuitToMainMenu()
    {
        Time.timeScale = 1f;    // Важно сбросить паузу перед загрузкой новой сцены
        SceneManager.LoadScene("MainMenu");
    }
}