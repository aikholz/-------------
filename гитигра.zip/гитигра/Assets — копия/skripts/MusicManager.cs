using UnityEngine;

public class MusicManager : MonoBehaviour
{
    public static MusicManager Instance;

    [Header("Audio Sources")]
    [SerializeField] private AudioSource musicSource;
    [SerializeField] private AudioSource sfxSource;

    [Header("Music")]
    [SerializeField] private AudioClip menuMusic;
    [SerializeField] private AudioClip levelMusic;

    [Header("SFX")]
    [SerializeField] private AudioClip coinSound;
    [SerializeField] private AudioClip exitSound;
    [SerializeField] private AudioClip buttonClick;
    [SerializeField] private AudioClip footstepSound;

    // Флаг: включены ли звуки
    private bool isSoundOn = true;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // Переключить звук (вкл/выкл)
    public void ToggleSound()
    {
        isSoundOn = !isSoundOn;

        Debug.Log("isSoundOn = " + isSoundOn);

        if (musicSource != null)
        {
            musicSource.mute = !isSoundOn;
            Debug.Log("Music muted: " + musicSource.mute);
        }
        else
        {
            Debug.Log("musicSource is NULL!");
        }

        if (sfxSource != null)
        {
            sfxSource.mute = !isSoundOn;
            Debug.Log("SFX muted: " + sfxSource.mute);
        }
        else
        {
            Debug.Log("sfxSource is NULL!");
        }
    }

    // Проверка перед проигрыванием звука
    public void PlayCoin()
    {
        if (isSoundOn && sfxSource != null)
            sfxSource.PlayOneShot(coinSound);
    }

    public void PlayExit()
    {
        if (isSoundOn && sfxSource != null)
            sfxSource.PlayOneShot(exitSound);
    }

    public void PlayButtonClick()
    {
        if (isSoundOn && sfxSource != null)
            sfxSource.PlayOneShot(buttonClick);
    }

    public void PlayMenuMusic()
    {
        if (musicSource != null)
        {
            musicSource.clip = menuMusic;
            musicSource.Play();
        }
    }

    public void PlayLevelMusic()
    {
        if (musicSource != null)
        {
            musicSource.clip = levelMusic;
            musicSource.Play();
        }
    }
}