using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    // Загружает первый уровень игры
    public void PlayGame()
    {
        SceneManager.LoadScene("Lev1");
    }

    // Открывает меню выбора уровней
    public void OpenLevelSelect()
    {
        SceneManager.LoadScene("LevelSelect");
    }

    // Сбрасывает все сохранённые рекорды (PlayerPrefs)
    public void ResetProgress()
    {
        PlayerPrefs.DeleteAll();
        PlayerPrefs.Save();
        Debug.Log("Progress Reset");
    }

    // Выход из игры: в редакторе останавливает Play Mode, в сборке закрывает приложение
    public void QuitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}