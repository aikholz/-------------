using UnityEngine;

// Управляет кастомным курсором мыши в игре
public class CursorManager : MonoBehaviour
{
    [Header("Cursor Sprites")]
    // Спрайт обычного курсора
    [SerializeField] private Texture2D defaultCursor;

    // Спрайт курсора при наведении на кнопки
    [SerializeField] private Texture2D buttonCursor;

    // Точка клика курсора (обычно 0,0 — верхний левый угол)
    [SerializeField] private Vector2 hotspot = Vector2.zero;

    void Start()
    {
        // При запуске устанавливаем обычный курсор
        SetDefaultCursor();
    }

    // Устанавливает обычный курсор (вызывается из CursorButton при уходе с кнопки)
    public void SetDefaultCursor()
    {
        Cursor.SetCursor(defaultCursor, hotspot, CursorMode.Auto);
    }

    // Устанавливает курсор для кнопок (вызывается из CursorButton при наведении)
    public void SetButtonCursor()
    {
        Cursor.SetCursor(buttonCursor, hotspot, CursorMode.Auto);
    }
}