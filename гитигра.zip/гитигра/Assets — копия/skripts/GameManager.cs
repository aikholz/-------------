using UnityEngine;
using TMPro;
public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [SerializeField] private TextMeshProUGUI coinText;
    [SerializeField] private TextMeshProUGUI timerText; // ← добавить таймер

    private int totalCoins;
    private int collectedCoins;
    private float elapsedTime; // ← время уровня

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(Instance.gameObject);
        }
        Instance = this;
    }

    void Start()
    {
        Coin[] coins = FindObjectsByType<Coin>(FindObjectsSortMode.None);
        totalCoins = coins.Length;
        collectedCoins = 0;
        elapsedTime = 0f; // ← сброс времени
        UpdateUI();
    }

    void Update()
    {
        elapsedTime += Time.deltaTime; // ← считаем время
        UpdateTimerUI();
    }

    public void AddCoins(int amount)
    {
        collectedCoins += amount;
        UpdateUI();
    }

    public void UpdateUI()
    {
        if (coinText != null)
            coinText.text = $"{collectedCoins} / {totalCoins}";
    }

    private void UpdateTimerUI()
    {
        if (timerText != null)
        {
            int minutes = Mathf.FloorToInt(elapsedTime / 60);
            int seconds = Mathf.FloorToInt(elapsedTime % 60);
            timerText.text = $"{minutes:00}:{seconds:00}";
        }
    }
    public int GetCollectedCoins() => collectedCoins;
    public int GetTotalCoins() => totalCoins;
    public float GetElapsedTime() => elapsedTime; // ← для сохранения времени
}